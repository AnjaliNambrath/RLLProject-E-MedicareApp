import { Addtocart } from './addtocart';

describe('Addtocart', () => {
  it('should create an instance', () => {
    expect(new Addtocart()).toBeTruthy();
  });
});
