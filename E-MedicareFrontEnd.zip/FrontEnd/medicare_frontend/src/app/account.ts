export class Account {
    constructor(public email:string,
        public name:string,
        public mobile:number,
        public password:string,
        public typeOfUser:string){}
}
